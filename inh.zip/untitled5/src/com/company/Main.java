package com.company;

import com.company.models.Staff;
import com.company.models.Student;
import com.company.models.User;

import java.util.Scanner;

public class Main {

    static int idForUsers;

    public static void main(String[] args) {

        Student student = new Student(1, "1", "1", "1", "1", 1);
        Student student1 = new Student(2, "2", "2", "2", "2", 2);
        Staff staff = new Staff(3, "3", "3", "3", "3", 3);
        Staff staff1 = new Staff(4, "4", "4", "4", "4", 4);
        User user = new User(11, "11", "11", "11", "11");
        User user1 = new User(12, "12", "12", "12", "12");
        User[] users = new User[10];
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("PRESS [1] ADD USER");
            System.out.println("PRESS [2] TO LIST USERS");
            System.out.println("PRESS [0] TO EXIT");
            int choice = scanner.nextInt();
            if (choice == 1) {
                System.out.println(
                        "PRESS [1] TO ADD STUDENT\n" +
                                "PRESS [2] TO ADD STAFF");
                choice = scanner.nextInt();
                if (choice == 1) {
                    System.out.println("login: ");
                    String login = scanner.next();
                    System.out.println("password: ");
                    String password = scanner.next();
                    System.out.println("name: ");
                    String name = scanner.next();
                    System.out.println("surname: ");
                    String surname = scanner.next();
                    System.out.println("gpa: ");
                    Double gpa = scanner.nextDouble();
                    users[idForUsers] = new Student(idForUsers, login, password, name, surname, gpa);
                } else if (choice == 2) {

                }
            } else if (choice == 2) {
                System.out.println(
                        "PRESS [1] TO LIST STUDENTS\n" +
                                "PRESS [2] TO LIST STAFF");
                choice = scanner.nextInt();
                if (choice == 1) {
                    show(users,1);

                } else if (choice == 2) {
                    show(users, 2);
                }
            } else if (choice == 0) {
                System.exit(0);
            }
        }
    }

    static void show(User[] users, int choice) {
        for (User user : users) {
            if (choice == 1) {
                if (user instanceof Student){
                    System.out.println(user);
                }

            }
        }
    }

}
